package main

import "h8-movies/handler"

func main() {
	handler.StartApp()
}
