package utils

import "fmt"

var RandomNumber = 10

func GetSecretKey() {
	fmt.Println(secretKey)
}
