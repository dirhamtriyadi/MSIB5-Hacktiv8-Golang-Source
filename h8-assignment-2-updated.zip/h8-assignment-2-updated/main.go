package main

import (
	"h8-assignment-2/handler"
)

func main() {
	handler.StartApp()
}
